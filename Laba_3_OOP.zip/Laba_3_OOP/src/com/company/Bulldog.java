package com.company;

public class Bulldog extends Dogs {
    @Override
    public void dog() {
        breed = "Bulldog";
        name = "Jack";
        age = 2;
        sex = 'M';
    }
}
