package com.company;

public abstract class Dogs {

    String breed;
    String name;
    int age;
    char sex;

    public void displayInfo(){
        System.out.println("\nПорода: " + breed + "\nИмя: " + name + "\nsex: " + sex + "\nВозраст: " + age);
    }
    public  abstract  void dog();
    }
