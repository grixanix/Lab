package com.company;

public class CaneCorso extends Dogs {
    @Override
    public void dog() {
        breed = "Cane Corso";
        name = "Nicka";
        age = 4;
        sex = 'W';
    }
}
