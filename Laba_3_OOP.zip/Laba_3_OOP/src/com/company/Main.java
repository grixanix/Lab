package com.company;
import java.util.Scanner;
// 2. Создать абстрактный класс, описывающий собак(Dog).
// С помощью наследования реализовать различные породы собак.
// Протестировать работу классов.
public class Main {
    public static void main(String[] args) {
        Shepherd shepherd = new Shepherd();
        Bulldog bulldog = new Bulldog();
        CaneCorso caneCorso = new CaneCorso();
        shepherd.dog();
        bulldog.dog();
        caneCorso.dog();
        shepherd.displayInfo();
        bulldog.displayInfo();
        caneCorso.displayInfo();
    }
}
