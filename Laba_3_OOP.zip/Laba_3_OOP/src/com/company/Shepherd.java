package com.company;

public class Shepherd extends Dogs {
    @Override
    public void dog() {
        breed = "Shepherd";
        name = "Grey";
        age = 4;
        sex = 'M';
    }
}
